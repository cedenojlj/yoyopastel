<?php return array (
  'cargar-compra' => 'App\\Http\\Livewire\\CargarCompra',
  'cargar-costo' => 'App\\Http\\Livewire\\CargarCosto',
  'cargar-venta' => 'App\\Http\\Livewire\\CargarVenta',
);