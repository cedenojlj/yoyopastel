

<?php $__env->startSection('content'); ?>

<div class="container">


        <div class="row">

                <div class="col-md-3">
                        <h5>Fecha:</h5>
                        <?php echo e($venta->fecha); ?>

                </div>

                <div class="col-md-3">
                        <h5>Factura:</h5>                       
                        <?php echo e(str_pad($venta->factura,15,'0',STR_PAD_LEFT)); ?>

                </div>

                <div class="col-md-3">

                        <a name="" id="" class="btn btn-primary" href="<?php echo e(route('ventas.index')); ?>"
                                role="button">Regresar
                        </a>

                </div>

        </div>

        

        <div class="row mt-3">

                <div class="col-md-3">
                        <h5>Rif:</h5>
                        <?php echo e($cliente->rif); ?>

                </div>
                <div class="col-md-3">
                        <h5>Cliente:</h5>
                        <?php echo e($cliente->nombre); ?>

                </div>
                <div class="col-md-3">
                        <h5>Telefono:</h5>
                        <?php echo e($cliente->telefono); ?>

                </div>

        </div>

        <div class="row mt-3">

                <div class="col-md-3">
                        <h5>Metodo de Pago:</h5>
                        <?php echo e($venta->metodo); ?>

                </div>

                <div class="col-md-3">
                        <h5>Moneda:</h5>
                        <?php echo e($venta->moneda); ?>

                </div>

        </div>

        <div class="row mt-4">

                <table class="table ">
                        <thead class="thead-light">
                                <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Producto</th>
                                        <th scope="col">Cantidad</th>
                                        <th scope="col">Precio</th>
                                        <th scope="col">Subtotal</th>
                                </tr>
                        </thead>
                        <tbody>

                                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                        <th scope="row"><?php echo e($index + 1); ?></th>
                                        <td><?php echo e($item->nombre); ?></td>
                                        <td><?php echo e($item->cantidad); ?></td>
                                        <td><?php echo e($item->precio); ?></td>
                                        <td><?php echo e($item->subtotal); ?></td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                </table>
        </div>


        <div class="row mt-3">

                <div class="col-md-2 offset-md-6">
                        <h5>Subtotal $:</h5>
                </div>

                <div class="col-md-2"><?php echo e(round($venta->subtotal,2)); ?></div>

        </div>

        <div class="row mt-3">

                <div class="col-md-2 offset-md-6">
                        <h5>Iva %:</h5>
                </div>
                <div class="col-md-4"><?php echo e(round(($venta->total - $venta->subtotal),2)); ?></div>
        </div>

        <div class="row mt-3">

                <div class="col-md-2 offset-md-6">
                        <h5>Total $:</h5>
                </div>
                <div class="col-md-4"><?php echo e(round($venta->total,2)); ?></div>
        </div> 
        
        <div class="row mt-3">

                <div class="col-md-2 offset-md-6">
                    <h5>Total Bs:</h5>
                </div>
                
                <div class="col-md-4"><?php echo e(round($venta->total*$venta->paridad,2)); ?></div>
            </div>


        

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/ventas/ver.blade.php ENDPATH**/ ?>