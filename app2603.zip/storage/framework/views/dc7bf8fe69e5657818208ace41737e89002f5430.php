

<?php $__env->startSection('content'); ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cargar-compra', [])->html();
} elseif ($_instance->childHasBeenRendered('uW8IX9M')) {
    $componentId = $_instance->getRenderedChildComponentId('uW8IX9M');
    $componentTag = $_instance->getRenderedChildComponentTagName('uW8IX9M');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uW8IX9M');
} else {
    $response = \Livewire\Livewire::mount('cargar-compra', []);
    $html = $response->html();
    $_instance->logRenderedChild('uW8IX9M', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>         

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/compras/create.blade.php ENDPATH**/ ?>