

<?php $__env->startSection('content'); ?>

<div class="container">


        <div class="row mt-3">

                <div class="col-md-3">

                        <h5>Codigo:</h5>
                        <?php echo e($producto->codigo); ?>


                </div>

                <div class="col-md-3">

                        <h5>Producto:</h5>
                        <?php echo e($producto->nombre); ?>


                </div>


                <div class="col-md-3">

                        <a name="" id="" class="btn btn-primary" href="<?php echo e(route('costos.index')); ?>"
                                role="button">Regresar
                        </a>

                </div>


        </div>



        <div class="row mt-4">

                <table class="table ">
                        <thead class="thead-light">
                                <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Codigo</th>
                                        <th scope="col">Material</th>
                                        <th scope="col">Cantidad</th> 
                                </tr>
                        </thead>
                        <tbody>

                                <?php $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                        <th scope="row"><?php echo e($index + 1); ?></th>
                                        <td><?php echo e($item->codigo); ?></td>
                                        <td><?php echo e($item->nombre); ?></td>
                                        <td><?php echo e($item->cantidad); ?></td>                                        
                                       
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                </table>
        </div>


        

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/costos/ver.blade.php ENDPATH**/ ?>