

<?php $__env->startSection('content'); ?>

<div class="container">
        <div class="row justify-content-center">
                <div class="col-md-12">
                        <div class="card">
                                <div class="card-header"><?php echo e(__('Escoger Empresa')); ?></div>

                                <div class="card-body">

                                        <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                                <ul>
                                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                        </div>
                                        <?php endif; ?>


                                        <form method="POST" action="<?php echo e(route('ventas.pdfempresarial')); ?>"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>

                                                <div class="form-group row">
                                                        <label for="empresa_id"
                                                                class="col-md-3 col-form-label text-md-right"><?php echo e(__('Empresa')); ?></label>



                                                        
                                                        <div class="col-md-6">

                                                                <select class="form-control <?php $__errorArgs = ['empresa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        name="empresa_id" required>

                                                                        <option value=""> --Select-- </option>

                                                                        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <option value="<?php echo e($empresa->id); ?>"> <?php echo e($empresa->nombre); ?></option>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                </select>

                                                                <?php $__errorArgs = ['empresa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                </div>


                                                <div class="form-group row">
                                                        <label for="reporte_id"
                                                                class="col-md-3 col-form-label text-md-right"><?php echo e(__('Reporte')); ?></label>



                                                        
                                                        <div class="col-md-6">

                                                                <select class="form-control <?php $__errorArgs = ['reporte_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        name="reporte_id" required>

                                                                        <option value=""> --Select-- </option>

                                                                        <option value="1"> Gestion </option>
                                                                        <option value="2"> Stock Material </option>
                                                                        <option value="3"> Stock Productos </option>                                                                       

                                                                </select>

                                                                <?php $__errorArgs = ['reporte_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                </div>


                                                <div class="form-group row mb-0 justify-content-left">
                                                        <div class="col-md-4 offset-md-3">
                                                                <button type="submit" class="btn btn-primary">
                                                                        <?php echo e(__('Aceptar')); ?>

                                                                </button>
                                                        </div>
                                                </div>


                                        </form>
                                </div>
                        </div>
                </div>
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/ventas/empresarial.blade.php ENDPATH**/ ?>