<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <style>
        table {

            width: 80%;
            border-collapse: collapse;
            margin: auto;
        }

        h1,td,h2 {

            text-align: center;
        }

        th,td {

            padding: 5px;
            height: 40px;
        }

        table,td,th {

            border: 1px solid black;
        }

        tr:nth-child(even) {
            
            background-color: #D6EEEE;
        }

        

    </style>

</head>

<body>

    <h1>Reporte de Ganancias y Perdidas</h1>
    <h2>Empresa <?php echo e($nombre); ?></h2>
    <h2>Moneda $</h2>

    
    <table>

       
        <tr>
            <th>Ventas</th>
            <td><?php echo e($ventas); ?></td>                
        </tr>

        <tr>
            <th>Costos</th>
            <td><?php echo e($costos); ?></td>                
        </tr>

        <tr>
            <th>Pagos</th>
            <td><?php echo e($pagos); ?></td>                
        </tr>

        <tr>
            <th>Total</th>
            <td><?php echo e($total); ?></td>                
        </tr>
        
        
    </table>
</body>

</html><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/ventas/gestion.blade.php ENDPATH**/ ?>