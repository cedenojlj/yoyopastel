<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"
        integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <!-- Styles Yoyo-->
    <link href="<?php echo e(asset('css/yoyo.css')); ?>" rel="stylesheet">

    <!-- Livewire -->
    <?php echo \Livewire\Livewire::styles(); ?>

   
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>"> Yoyopastel </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                        <?php if(auth()->guard()->check()): ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperadmin')): ?>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('empresas.index')); ?>">Empresas</a>
                        </li>
                            
                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isSuperadmin','isAdmin'])): ?>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('empleados.index')); ?>">Empleados</a>
                        </li>

                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isSaller')): ?>  

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('proveedors.index')); ?>">Proveedores</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('compras.index')); ?>">Compras</a>
                        </li>

                        <?php endif; ?>



                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('clientes.index')); ?>">Clientes</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('ventas.index')); ?>">Ventas</a>
                        </li>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isSaller')): ?>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button"
                                aria-expanded="false">Productos</a>
                            <div class="dropdown-menu">

                                <a class="dropdown-item" href="<?php echo e(route('productos.index')); ?>">Productos</a>
                                <a class="dropdown-item" href="<?php echo e(route('materials.index')); ?>">Materiales</a>
                                <a class="dropdown-item" href="<?php echo e(route('costos.index')); ?>">Costos</a>
                                <a class="dropdown-item" href="<?php echo e(route('categorias.index')); ?>">Categorias</a>
                                <a class="dropdown-item" href="<?php echo e(route('invmaterials.index')); ?>">Inventario
                                    Materiales</a>
                                <a class="dropdown-item" href="<?php echo e(route('invproductos.index')); ?>">Inventario
                                    Productos</a>
                                <a class="dropdown-item" href="<?php echo e(route('paridads.index')); ?>">Paridad</a>

                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('pagos.index')); ?>">Pagos</a>
                        </li>


                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button"
                                aria-expanded="false">Reportes</a>
                            <div class="dropdown-menu">

                                <a class="dropdown-item" href="<?php echo e(route('ventas.gestion')); ?>" target="_blank">Gestion General</a>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isSuperadmin')): ?>

                                <a class="dropdown-item" href="<?php echo e(route('ventas.empresarial')); ?>" target="_blank">Gestion Empresarial</a>
                                    
                                <?php endif; ?>
                                
                                <a class="dropdown-item" href="<?php echo e(route('ventas.pdfStockProducto')); ?>" target="_blank">Stock Producto</a>

                                <a class="dropdown-item" href="<?php echo e(route('ventas.pdfStockMaterial')); ?>" target="_blank">Stock Material</a>

                                <a class="dropdown-item" href="<?php echo e(route('ventas.crearCaja')); ?>" target="_blank">Caja</a>

                            </div>
                        </li>

                        <?php endif; ?>

                        <?php endif; ?>

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                        <?php endif; ?>
                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <!-- Livewire -->
    <?php echo \Livewire\Livewire::scripts(); ?>


    <script>

         window.livewire.on('userStore', () => {
            $('#exampleModal').modal('show');
        });

        window.livewire.on('userClose', () => {
            $('#exampleModal').modal('hide');
        });

    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/layouts/app.blade.php ENDPATH**/ ?>