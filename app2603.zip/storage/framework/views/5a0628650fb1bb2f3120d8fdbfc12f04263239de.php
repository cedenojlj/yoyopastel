<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        table {

            width: 100%;
            border-collapse: collapse;
            margin: auto;
            border-top: 1px dashed black;
        }

        
        th,
        td {                    
            text-align: center;
        }

      

        .bordes th{

            border-top: 1px dashed black;

        }

        .bordes td{

            border-top: 1px dashed black;

        }

        .centro{

            text-align:center;

        }

        .negrita{

            font-weight: bold;
        }

        .ticket{

            width: 100%;
        }

        .margensuperior{

            margin-top: 20px;
        }

       
    </style>

</head>

<body class="ticket">

   
    
    <table>
                
        <tr><td> <?php echo e($empresa->nombre); ?></td></tr>    
        <tr><td> <?php echo e($empresa->rif); ?></td></tr>    
        <tr><td> <?php echo e($empresa->direccion); ?></td></tr>    

    </table>

    <h4 class="centro">Orden de Entrega</h4>  

   
    <table>

    <tr><td> Entregado a:</td></tr>    
    <tr><td> <?php echo e($cliente->nombre); ?></td></tr>
    <tr><td> Cedula/Rif: </td></tr>        
    <tr><td> <?php echo e($cliente->rif); ?></td></tr>        
    
    <tr><td>Pedido Nº</td></tr>
    <tr><td><?php echo e(str_pad($venta->factura,10,'0',STR_PAD_LEFT)); ?> </td></tr>
    <tr><td>Fecha:</td></tr>    
    <tr><td><?php echo e($venta->created_at); ?></td></tr>     

    </table>
       
   
    <table class="table bordes margensuperior">
        <thead>
            <tr>
                
                <th>Producto</th>                             
                <th>BsD</th>

            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indice => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>                
                
                <td><?php echo e($producto->producto); ?>x<?php echo e(round($producto->cantidad,2)); ?></td>                
                
                <td><?php echo e(round($producto->subtotal*$venta->paridad,2)); ?></td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td class="negrita">Subtotal:</td>
                <td class="negrita"><?php echo e(round($venta->subtotal*$venta->paridad,2)); ?></td>                
            </tr>

            <tr>
                <td class="negrita">Iva:</td>
                <td class="negrita"><?php echo e(round((($venta->total - $venta->subtotal)*$venta->paridad),2)); ?></td>                
            </tr>

            <tr>
                <td class="negrita">Total:</td>
                <td class="negrita"><?php echo e(round($venta->total*$venta->paridad,2)); ?></td>                
            </tr>           

        </tbody>
    </table>

    
        <p class="centro"> !!! GRACIAS POR SU COMPRA !!!</p>
    
    


</body>

</html><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/ventas/ticket.blade.php ENDPATH**/ ?>