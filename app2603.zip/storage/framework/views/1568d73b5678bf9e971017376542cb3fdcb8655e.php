

<?php $__env->startSection('content'); ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cargar-venta', [])->html();
} elseif ($_instance->childHasBeenRendered('KjX3EYj')) {
    $componentId = $_instance->getRenderedChildComponentId('KjX3EYj');
    $componentTag = $_instance->getRenderedChildComponentTagName('KjX3EYj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KjX3EYj');
} else {
    $response = \Livewire\Livewire::mount('cargar-venta', []);
    $html = $response->html();
    $_instance->logRenderedChild('KjX3EYj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>         

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/ventas/create.blade.php ENDPATH**/ ?>