<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        table {

            width: 80%;
            border-collapse: collapse;
            margin: auto;
        }

        h1,
        td,
        h2,
        h3 {

            text-align: center;
        }

        th,
        td {

            padding: 5px;
            height: 40px;
        }

        table,
        td,
        th {

            border: 1px solid black;
        }

        tr:nth-child(even) {

            background-color: #D6EEEE;
        }
    </style>

</head>

<body>
    
    <h1>Reporte de Caja</h1>
    <h2>Empresa <?php echo e($empresa); ?></h2>
    <h3>Empleado <?php echo e($empleado); ?></h3>
    <h3>Fecha <?php echo e($fecha); ?></h3>

    <h4>Moneda Bolivares</h4>

    <table>

        <?php $__currentLoopData = $bolivares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bolivar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th><?php echo e($bolivar->metodo); ?></th>
            <td><?php echo e(round($bolivar->total,2)); ?></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <?php if($totalbolivares>0): ?>

        <tr>
            <th>Total</th>
            <td><?php echo e(round($totalbolivares,2)); ?></td>
        </tr>

        <?php else: ?>

        <p>Sin Resultados</p>

        <?php endif; ?>

    </table>

    <h4>Moneda Dolares</h4>

    <table>

        <?php $__currentLoopData = $dolares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dolar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th><?php echo e($dolar->metodo); ?></th>
            <td><?php echo e(round($dolar->total,2)); ?></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <?php if($totaldolares>0): ?>

        <tr>
            <th>Total</th>
            <td><?php echo e(round($totaldolares,2)); ?></td>
        </tr>

        <?php else: ?>

        <p>Sin Resultados</p>

        <?php endif; ?>  

    </table>
</body>

</html><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/ventas/pdfcaja.blade.php ENDPATH**/ ?>