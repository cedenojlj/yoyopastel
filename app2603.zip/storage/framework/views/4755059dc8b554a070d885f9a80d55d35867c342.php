

<?php $__env->startSection('content'); ?>

<div class="container">
        <div class="row justify-content-center">
                <div class="col-md-12">
                        <div class="card">
                                <div class="card-header"><?php echo e(__('Reporte de Caja')); ?></div>

                                <div class="card-body">

                                        <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                                <ul>
                                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($error); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                        </div>
                                        <?php endif; ?>


                                        <form method="POST" action="<?php echo e(route('ventas.pdfCaja')); ?>"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>

                                                <div class="form-group row">
                                                        <label for="empresa_id"
                                                                class="col-md-3 col-form-label text-md-right"><?php echo e(__('Empresa')); ?></label>

                                                        <div class="col-md-6">

                                                                <select class="form-control <?php $__errorArgs = ['empresa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        name="empresa_id" required>

                                                                        <option value=""> --Select-- </option>

                                                                        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <option value="<?php echo e($empresa->id); ?>"> <?php echo e($empresa->nombre); ?></option>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                </select>

                                                                <?php $__errorArgs = ['empresa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                </div>

                                                <div class="form-group row">
                                                        <label for="empleado_id"
                                                                class="col-md-3 col-form-label text-md-right"><?php echo e(__('Empleados')); ?></label>

                                                        <div class="col-md-6">

                                                                <select class="form-control <?php $__errorArgs = ['empleado_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        name="empleado_id" required>

                                                                        <option value=""> --Select-- </option>

                                                                        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <option value="<?php echo e($empleado->id); ?>"> <?php echo e($empleado->nombre. "
                                                                                ".$empleado->apellido); ?></option>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                </select>

                                                                <?php $__errorArgs = ['empleado_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                </div>

                                                <div class="form-group row">
                                                        <label for="fecha"
                                                                class="col-md-3 col-form-label text-md-right"><?php echo e(__('Fecha')); ?></label>

                                                        <div class="col-md-6">
                                                                <input id="fecha" type="date"
                                                                        class="form-control <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                        name="fecha" value="<?php echo e(old('fecha')); ?>"
                                                                        required autocomplete="fecha" autofocus>

                                                                <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                </div>


                                                <div class="form-group row mb-0 justify-content-left">
                                                        <div class="col-md-4 offset-md-3">
                                                                <button type="submit" class="btn btn-primary">
                                                                        <?php echo e(__('Aceptar')); ?>

                                                                </button>
                                                        </div>
                                                </div>


                                        </form>
                                </div>
                        </div>
                </div>
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/ventas/crearcaja.blade.php ENDPATH**/ ?>