

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>


            <div class="card">
                <div class="card-header"><?php echo e(__('Editar Rol Empleado')); ?></div>

                <div class="card-body">  

                    

                    <div class="row">

                        <div class="col-md-3">
                            <h5>Cedula o Rif:</h5>
                            <?php echo e($empleado->cedula); ?>


                        </div>

                        <div class="col-md-3">
                            <h5>Nombre:</h5>
                            <?php echo e($empleado->nombre); ?>


                        </div>

                        <div class="col-md-3">
                            <h5>Apellido:</h5>
                            <?php echo e($empleado->apellido); ?>


                        </div>

                        <div class="col-md-3">

                            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('empleados.index')); ?>"
                                role="button">Regresar
                        </a>

                        </div>

                    </div>

                   <div class="row mt-3">
                       <div class="col-md-12">

                        <form method="POST" action="<?php echo e(route('empleados.rolUpdate',$empleado->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
    
                            
                            
                            <div class="form-group row">
                                <label for="rol" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Rol')); ?></label>
    
                                <div class="col-md-6">
    
                                    <select class="form-control <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rol"
                                        required>
    
                                        <option value=""> --Select-- </option>    
                                            
                                        <option <?php echo e($rol=='superadmin' ? 'selected' : ''); ?> value="1"> Superadmin</option>                                         
                                        <option <?php echo e($rol=='admin' ? 'selected' : ''); ?> value="2"> Admin</option>                                         
                                        <option <?php echo e($rol=='user' ? 'selected' : ''); ?> value="3"> User</option>                                         
                                        <option <?php echo e($rol=='saller' ? 'selected' : ''); ?> value="4"> Vendedor</option>                                        
                                          
    
                                    </select>
    
                                    <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
    
    
    
    
                            <div class="form-group row mb-0 justify-content-center">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Aceptar')); ?>

                                    </button>
    
                                    <a name="" id="" class="btn btn-primary" href="<?php echo e(route('empleados.index')); ?>"
                                        role="button">Cancel</a>
                                </div>
                            </div>
    
    
                        </form>

                       </div>                       
                   </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/empleados/rol.blade.php ENDPATH**/ ?>