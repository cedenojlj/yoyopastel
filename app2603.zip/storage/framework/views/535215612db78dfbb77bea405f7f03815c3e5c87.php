

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
        <img src="<?php echo e(asset('storage/img/panaderia2min.png')); ?>" alt="" width="100%" height="100%">
    </div>  
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/home.blade.php ENDPATH**/ ?>