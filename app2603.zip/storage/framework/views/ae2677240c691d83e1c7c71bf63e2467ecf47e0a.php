

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Ventas</div>

                <div class="card-body">

                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success card shadow">
                        <p><?php echo e($message); ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <div class="row mb-3 justify-content-around">
                        <div class="col-md-7">

                            <a name="" id="" class="btn btn-primary" 
                            href="<?php echo e(route('ventas.create')); ?>" role="button" target="_blank">Crear</a>
                            <a name="" id="" class="btn btn-primary" 
                            href="<?php echo e(route('ventas.reporte')); ?>" role="button">Excel</a>

                        </div>
                        <div class="col-md-5">

                            <form class="form-inline" method="GET" 
                            action="<?php echo e(route('ventas.search')); ?>">
                                <?php echo csrf_field(); ?>
                                <input class="form-control mr-sm-2" type="text" placeholder="Search"  name="search">
                                <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
                              </form>

                        </div>
                    </div>

                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Fecha</th>
                                <th scope="col">Factura</th>
                                <th scope="col">Total $</th>
                                <th scope="col">Cliente</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <th scope="row"><?php echo e($venta->id); ?></th>
                                <td><?php echo e($venta->fecha); ?></td>
                                <td><?php echo e($venta->factura); ?></td>
                                <td><?php echo e($venta->total); ?></td>
                                <td><?php echo e($venta->cliente->nombre); ?></td>
                                

                                <td>
                                    
                                    <form action="<?php echo e(route('ventas.destroy', $venta->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        
                                        <a name="" id="" class="btn btn-info"
                                        href="<?php echo e(route('ventas.factura', $venta->id)); ?>" target="_blank" role="button"><i class="far fa-file-alt"></i></a>

                                        <a name="" id="" class="btn btn-success"
                                        href="<?php echo e(route('ventas.show', $venta->id)); ?>" role="button"><i class="fas fa-pencil-alt"></i></a>
                                       
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isSuperadmin','isAdmin'])): ?>

                                        <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>

                                        <?php endif; ?>

                                    </form>
                            
                                </td>

                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($ventas->links()); ?>


                   

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/ventas/index.blade.php ENDPATH**/ ?>