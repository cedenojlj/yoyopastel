<div class="container">
    

    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Crear Compra')); ?></div>

                <div class="card-body">

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('message')): ?>

                        <div class="alert alert-danger">
                            <?php echo e(session('message')); ?>

                        </div>

                    <?php endif; ?>
                   

                    <?php if($errorMaterial): ?>

                    <div class="alert alert-danger">

                        <p>Material no encontrado</p>

                    </div>

                    <?php endif; ?>

                    <?php if($errorProveedor): ?>

                    <div class="alert alert-danger">

                        <p>Coloque un proveedor valido</p>

                    </div>

                    <?php endif; ?>

                     
                   
                     <div class="row mb-3">

                        <div class="col-md-4">
                            <label for="factura" class="form-label">Factura</label>
                            <input type="factura" wire:model="factura" class="form-control" id="factura"
                                placeholder="Numero de factura" autocomplete="off">

                        </div>

                        <div class="col-md-4">
                            <label for="fecha" class="form-label">Fecha</label>
                            <input type="date" wire:model="fecha" class="form-control" id="fecha">

                        </div>

                    </div>

                    

                    <?php if(!$mostrar): ?>

                    <div class="row">

                        <div class="col-md-12 col-sm-12">

                            <button type="button" wire:click="buscarProveedor"
                                class="btn btn-primary mb-2">Buscar</button>

                        </div>

                        <div class="col-md-6 col-sm-12">

                            <div class="search-input">
                                <input type="search" wire:model="search" class="form-control" id="search"
                                    placeholder="Proveedor" autocomplete="off">

                                <div class="autocom">
                                    <?php if(!empty($proveedores)): ?>
                                    <ul>
                                        <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($proveedor->nombre); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <?php endif; ?>
                                </div>
                                
                            </div>

                        </div>                       


                    </div>


                    <?php endif; ?>

                   

                    
                    
                    <?php if($mostrar): ?>

                        <div class="row">

                            <div class="col-md-3">
                                <h5>Rif:</h5>
                                <?php echo e($proveedor->rif); ?>

                            </div>
                            <div class="col-md-3">
                                <h5>Proveedor:</h5>
                                <?php echo e($proveedor->nombre); ?>

                            </div>
                            <div class="col-md-3">
                                <h5>Telefono:</h5>
                                <?php echo e($proveedor->telefono); ?>

                            </div>

                            <div class="col-md-3">
                                <button type="button" wire:click="cerrarProveedor" class="btn btn-danger"><i
                                        class="far fa-trash-alt"></i></button>
                            </div>
                        </div>

                    <?php endif; ?>


                    

                    <div class="row justify-content-between ml-1 mt-3">

                        <h3>Carga de Materiales</h3>

                        

                        <div class="row">

                            <div class="col-md-12 mb-2">

                                <button type="button" wire:click="cargarMaterial" class="btn btn-primary">Nuevo</button>

                            </div>

                            <div class="col-md-6 mt-2">

                                <label for="material" class="form-label">Material</label>
                                <div class="search-input">
                                    <input id="material" wire:model="material" type="text"
                                        class="form-control <?php $__errorArgs = ['material'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="material"
                                        placeholder="Material" required autocomplete="off">

                                    <div class="autocom">
                                        <?php if(!empty($materiales)): ?>
                                        <ul>
                                            <?php $__empty_1 = true; $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li><?php echo e($material->nombre); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <li>sin resultados</li>
                                            <?php endif; ?>
                                        </ul>
                                        <?php endif; ?>
                                    </div>


                                </div>
                            </div>


                            <div class="col-md mt-2">

                                <label for="cantidad" class="form-label">Cantidad</label>
                                <input id="cantidad" wire:model="cantidad" type="number"
                                    class="form-control <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cantidad"
                                    value="<?php echo e(old('cantidad')); ?>" required step="0.01" placeholder="1">

                            </div>

                            <div class="col-md mt-2">
                                <label for="costo" class="form-label">Costo</label>
                                <input id="costo" wire:model="costo" type="number"
                                    class="form-control <?php $__errorArgs = ['costo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="costo"
                                    value="<?php echo e(old('costo')); ?>" required step="0.01" placeholder="1">


                            </div>

                            <div class="col-md mt-2">

                                <label for="iva" class="form-label">Iva</label>
                                <input id="iva" wire:model="iva" type="number"
                                    class="form-control <?php $__errorArgs = ['iva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="iva"
                                    value="<?php echo e(old('iva')); ?>" required step="0.01" placeholder="1">

                            </div>


                        </div>

                    </div>


                    <div class="row mt-4">
                        <table class="table ">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Material</th>
                                    <th scope="col">Cantidad</th>
                                    <th scope="col">Costo</th>
                                    <th scope="col">Subtotal</th>
                                    <th scope="col">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $listaMateriales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <th scope="row"><?php echo e($index + 1); ?></th>
                                    <td><?php echo e($item['nombre']); ?></td>
                                    <td><?php echo e($item['cantidad']); ?></td>
                                    <td><?php echo e($item['costo']); ?></td>
                                    <td><?php echo e($item['subtotalitem']); ?></td>

                                    <td>
                                        <button type="button" wire:click="borrarMaterial(<?php echo e($index); ?>)"
                                            class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                                    </td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>

                    <div class="row">

                        <div class="col-md-2 offset-md-6">
                            <h5>Subtotal $:</h5>
                        </div>
                        <div class="col-md-2"><?php echo e(round($subtotal,2)); ?></div>

                    </div>

                    <div class="row mt-3">

                        <div class="col-md-2 offset-md-6">
                            <h5>Iva %:</h5>
                        </div>
                        <div class="col-md-4"><?php echo e(round((($iva/100)*$subtotal),2)); ?></div>
                    </div>

                    <div class="row mt-3">

                        <div class="col-md-2 offset-md-6">
                            <h5>Total $:</h5>
                        </div>
                        <div class="col-md-4"><?php echo e(round($total,2)); ?></div>
                    </div>


                    <div class="row justify-content-end mt-3">

                        <div class="col-md-3">

                            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('compras.index')); ?>"
                                role="button">Cancel
                            </a>

                            <button type="button" wire:click="cargarCompra" class="btn btn-primary">Aceptar</button>
                        </div>


                    </div>

                    
                </div>
            </div>
        </div>
    </div>



</div>
<?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/livewire/cargar-compra.blade.php ENDPATH**/ ?>