<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        table {

            width: 100%;
            border-collapse: collapse;
            margin: auto;
        }

        
        th,
        td {

            padding: 5px;
            height: 22px;
            text-align: center;
        }

        table,
        td,
        th {

            border: 1px solid black;
        }

        .der{

            text-align:right;
        }
        p{
            line-height: 20%;
        }

        .negrita{

            font-weight: bold;
        }

       
    </style>

</head>

<body>

    <h2>Empresa <?php echo e($empresa->nombre); ?></h2>
    <p>Rif: <?php echo e($empresa->rif); ?></p>
    <p>Dirección: <?php echo e($empresa->direccion); ?></p>
    <p>Tlf: <?php echo e($empresa->telefono); ?></p>
    <p>Fecha: <?php echo e($venta->fecha); ?></p>

    <h3>Factura Nº <?php echo e(str_pad($venta->factura,10,'0',STR_PAD_LEFT)); ?> </h3>
    <p>Facturado a:</p>
    <p>Nombre: <?php echo e($cliente->nombre); ?></p>
    <p>Rif: <?php echo e($cliente->rif); ?></p>
    <p>Dirección: <?php echo e($cliente->direccion); ?></p>

   
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Subtotal</th>

            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indice => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>                
                <td><?php echo e($indice+1); ?></td>
                <td><?php echo e($producto->producto); ?></td>
                <td><?php echo e(round($producto->cantidad,2)); ?></td>
                <td><?php echo e(round($producto->precio*$venta->paridad,2)); ?></td>                
                <td><?php echo e(round($producto->subtotal*$venta->paridad,2)); ?></td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td colspan="4" class="der negrita">Subtotal:</td>
                <td class="negrita"><?php echo e(round($venta->subtotal*$venta->paridad,2)); ?></td>                
            </tr>

            <tr>
                <td colspan="4" class="der negrita">Iva:</td>
                <td class="negrita"><?php echo e(round((($venta->total - $venta->subtotal)*$venta->paridad),2)); ?></td>                
            </tr>

            <tr>
                <td colspan="4" class="der negrita">Total:</td>
                <td class="negrita"><?php echo e(round($venta->total*$venta->paridad,2)); ?></td>                
            </tr>

        </tbody>
    </table>

</body>

</html><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/ventas/factura.blade.php ENDPATH**/ ?>