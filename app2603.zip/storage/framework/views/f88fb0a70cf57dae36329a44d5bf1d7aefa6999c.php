<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <style>
        table {

            width: 100%;
            border-collapse: collapse;
            margin: auto;
        }

        h1,td,h2 {

            text-align: center;
        }

        th,td {

            padding: 5px;
        }

        table,td,th {

            border: 1px solid black;
        }

        tr:nth-child(even) {
            
            background-color: #D6EEEE;
        }

    </style>

</head>

<body>

    <h1>Reporte de Stock de Productos</h1>
    <h2>Empresa <?php echo e($nombre); ?></h2>

    <table class="tabla">
        <thead>
            <tr>
                <th>#</th>
                <th>Producto</th>
                <th>Entrada</th>
                <th>Salida</th>
                <th>Stock</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indice => $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($indice +1); ?></td>
                <td><?php echo e($producto->producto); ?></td>
                <td><?php echo e($producto->entradas); ?></td>
                <td><?php echo e($producto->salidas); ?></td>
                <td><?php echo e($producto->Stock); ?></td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>

    
</body>

</html><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/invproductos/stock.blade.php ENDPATH**/ ?>