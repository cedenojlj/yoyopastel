<div class="container">


    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Crear Venta')); ?></div>

                <div class="card-body">

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('message')): ?>

                    <div class="alert alert-danger">
                        <?php echo e(session('message')); ?>

                    </div>

                    <?php endif; ?>


                    <?php if($errorProducto): ?>

                    <div class="alert alert-danger">

                        <p>Producto no encontrado</p>

                    </div>

                    <?php endif; ?>

                    <?php if($errorCliente): ?>

                    <div class="alert alert-danger">

                        <p>Coloque un cliente valido</p>

                    </div>

                    <?php endif; ?>

                    

                    <div class="row mb-3">

                        <div class="col-md-4">
                            <h5>Factura:</h5>
                            <?php echo e(str_pad($factura,15,'0',STR_PAD_LEFT)); ?>


                        </div>

                        <div class="col-md-4">
                            <h5>Fecha:</h5>
                            <?php echo e($fecha); ?>


                        </div>

                        <div class="col-md-4">
                            <h5>Tasa de Cambio:</h5>
                            <?php echo e($paridad); ?>


                        </div>

                    </div>

                    

                    <?php if(!$mostrar): ?>

                    <div class="row">

                        <div class="col-md-12 col-sm-12">

                            <button type="button" wire:click="buscarCliente"
                                class="btn btn-primary mb-2">Buscar</button>

                        </div>

                        <div class="col-md-6 col-sm-12">

                            <div class="search-input">
                                <input type="search" wire:model="search" class="form-control" id="search"
                                    placeholder="Cliente" autocomplete="off">

                                <div class="autocom">
                                    <?php if(!empty($clientes)): ?>
                                    <ul>
                                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($cliente->nombre); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <?php endif; ?>
                                </div>
                                
                            </div>

                        </div>


                    </div>


                    <?php endif; ?>



                    

                    <?php if($mostrar): ?>

                    <div class="row">

                        <div class="col-md-3">
                            <h5>Rif:</h5>
                            <?php echo e($cliente->rif); ?>

                        </div>
                        <div class="col-md-3">
                            <h5>Cliente:</h5>
                            <?php echo e($cliente->nombre); ?>

                        </div>
                        <div class="col-md-3">
                            <h5>Telefono:</h5>
                            <?php echo e($cliente->telefono); ?>

                        </div>

                        <div class="col-md-3">
                            <button type="button" wire:click="cerrarCliente" class="btn btn-danger"><i
                                    class="far fa-trash-alt"></i></button>
                        </div>
                    </div>

                    <?php endif; ?>

                    


                    <div class="row mt-3">

                        <div class="col-md-3">

                            <div class="form-group">
                                <label for="metodo">Metodo</label>
                                <select wire:model="metodo" class="form-control" name="metodo" id="metodo">
                                    <option value="Debito">Debito</option>
                                    <option value="Credito">Credito</option>
                                    <option value="Efectivo">Efectivo</option>
                                </select>
                            </div>

                        </div>

                        <div class="col-md-3">

                            <div class="form-group">
                                <label for="moneda">Moneda</label>
                                <select wire:model="moneda" class="form-control" name="moneda" id="moneda">
                                    <option value="Bs">Bs</option>
                                    <option value="Usd">Usd</option>
                                </select>
                            </div>

                        </div>


                    </div>


                    

                    <div class="row justify-content-between ml-1 mt-3">

                        <h3>Carga de Productos</h3>

                        

                        <div class="row">

                            <div class="col-md-12 mb-2">

                                <button type="button" wire:click="cargarProducto" class="btn btn-primary">Nuevo</button>

                            </div>

                            <div class="col-md-6 mt-2">

                                <label for="producto" class="form-label">Producto</label>
                                <div class="search-input">
                                    <input id="producto" wire:model="producto" type="text"
                                        class="form-control <?php $__errorArgs = ['producto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="producto"
                                        placeholder="producto" required autocomplete="off">

                                    <div class="autocom">
                                        <?php if(!empty($productos)): ?>
                                        <ul>
                                            <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li><?php echo e($producto->nombre); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <li>sin resultados</li>
                                            <?php endif; ?>
                                        </ul>
                                        <?php endif; ?>
                                    </div>


                                </div>
                            </div>


                            <div class="col-md mt-2">

                                <label for="cantidad" class="form-label">Cantidad</label>
                                <input id="cantidad" wire:model="cantidad" type="number"
                                    class="form-control <?php $__errorArgs = ['cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cantidad"
                                    value="<?php echo e(old('cantidad')); ?>" required step="0.01" placeholder="1">

                            </div>

                            <div class="col-md mt-2">
                                <label for="precio" class="form-label">Precio</label>
                                <input id="precio" wire:model="precio" type="number"
                                    class="form-control <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="precio"
                                    value="<?php echo e(old('precio')); ?>" required step="0.01" placeholder="1">


                            </div>

                            <div class="col-md mt-2">

                                <label for="iva" class="form-label">Iva</label>
                                <input id="iva" wire:model="iva" type="number"
                                    class="form-control <?php $__errorArgs = ['iva'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="iva"
                                    value="<?php echo e(old('iva')); ?>" required step="0.01" placeholder="1">

                            </div>


                        </div>

                    </div>


                    <div class="row mt-4">
                        <table class="table ">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Producto</th>
                                    <th scope="col">Cantidad</th>
                                    <th scope="col">Precio</th>
                                    <th scope="col">Subtotal</th>
                                    <th scope="col">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $listaProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <th scope="row"><?php echo e($index + 1); ?></th>
                                    <td><?php echo e($item['nombre']); ?></td>
                                    <td><?php echo e($item['cantidad']); ?></td>
                                    <td><?php echo e($item['precio']); ?></td>
                                    <td><?php echo e($item['subtotalitem']); ?></td>

                                    <td>
                                        <button type="button" wire:click="borrarProducto(<?php echo e($index); ?>)"
                                            class="btn btn-danger"><i class="far fa-trash-alt"></i></button>
                                    </td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>


                    <div class="row">

                        <div class="col-md-2 offset-md-6">
                            <h5>Subtotal $:</h5>
                        </div>
                        <div class="col-md-2"><?php echo e(round($subtotal,2)); ?></div>

                    </div>

                    <div class="row mt-3">

                        <div class="col-md-2 offset-md-6">
                            <h5>Iva %:</h5>
                        </div>
                        <div class="col-md-4"><?php echo e(round((($iva/100)*$subtotal),2)); ?></div>
                    </div>

                    <div class="row mt-3">

                        <div class="col-md-2 offset-md-6">
                            <h5>Total $:</h5>
                        </div>
                        <div class="col-md-4"><?php echo e(round($total,2)); ?></div>
                    </div>

                    <div class="row mt-3">

                        <div class="col-md-2 offset-md-6">
                            <h5>Total Bs:</h5>
                        </div>
                        <div class="col-md-4"><?php echo e(round($total*$paridad,2)); ?></div>
                    </div>


                    
                    

                    <div class="row mt-3">

                        <div class="col-md-3">
                            <label for="pagoBs" class="form-label">pagoBs</label>
                                <input id="pagoBs" wire:model="pagoBs" type="number"
                                    class="form-control <?php $__errorArgs = ['pagoBs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pagoBs"
                                    value="" step="0.01" placeholder="0">
                        </div>

                        <div class="col-md-3">

                            <div class="form-group">
                                <label for="metodoPagoBs">Metodo</label>
                                <select wire:model="metodoPagoBs" class="form-control" name="metodoPagoBs" id="metodoPagoBs">
                                    <option value="Debito">Debito</option>
                                    <option value="Credito">Credito</option>
                                    <option value="Efectivo">Efectivo</option>
                                </select>
                            </div>

                        </div>

                        <div class="col-md-3">
                            <label for="vueltoBs" class="form-label">vueltoBs</label>
                                <input id="vueltoBs" wire:model="vueltoBs" type="number"
                                    class="form-control <?php $__errorArgs = ['vueltoBs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="vueltoBs"
                                    value="" step="0.01" placeholder="0">
                        </div>

                        <div class="col-md-3">

                            <div class="form-group">
                                <label for="metodoVueltoBs">Metodo</label>
                                <select wire:model="metodoVueltoBs" class="form-control" name="metodoVueltoBs" id="metodoVueltoBs">
                                    <option value="Debito">Debito</option>
                                    <option value="Credito">Credito</option>
                                    <option value="Efectivo">Efectivo</option>
                                </select>
                            </div>

                        </div>

                        
                    </div>

                    <div class="row">

                        <div class="col-md-3">
                            <label for="pagoDol" class="form-label">pagoDol</label>
                                <input id="pagoDol" wire:model="pagoDol" type="number"
                                    class="form-control <?php $__errorArgs = ['pagoDol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pagoDol"
                                    value="" step="0.01" placeholder="0">
                        </div>

                        <div class="col-md-3">

                            <div class="form-group">
                                <label for="metodoPagoDol">Metodo</label>
                                <select wire:model="metodoPagoDol" class="form-control" name="metodoPagoDol" id="metodoPagoDol">
                                    <option value="Debito">Debito</option>
                                    <option value="Credito">Credito</option>
                                    <option value="Efectivo">Efectivo</option>
                                </select>
                            </div>

                        </div>

                        <div class="col-md-3">
                            <label for="vueltoDol" class="form-label">vueltoDol</label>
                                <input id="vueltoDol" wire:model="vueltoDol" type="number"
                                    class="form-control <?php $__errorArgs = ['vueltoDol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="vueltoDol"
                                    value="" step="0.01" placeholder="0">
                        </div>

                        <div class="col-md-3">

                            <div class="form-group">
                                <label for="metodoVueltoDol">Metodo</label>
                                <select wire:model="metodoVueltoDol" class="form-control" name="metodoVueltoDol" id="metodoVueltoDol">
                                    <option value="Debito">Debito</option>
                                    <option value="Credito">Credito</option>
                                    <option value="Efectivo">Efectivo</option>
                                </select>
                            </div>

                        </div>

                        
                    </div>

                    



                    <div class="row justify-content-end mt-3">

                        <div class="col-md-3">

                            <a name="" id="" class="btn btn-primary" href="<?php echo e(route('ventas.index')); ?>"
                                role="button">Cancel
                            </a>

                            <button type="button" wire:click="cargarVenta" class="btn btn-primary">Aceptar</button>
                        </div>


                    </div>

                    <div class="row modal-open">

                       
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Permiso de Eliminación</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">

                                            <div class="col-md-12 mt-2">
                                                <label for="clave" class="form-label">Clave</label>
                                                <input id="clave" wire:model.defer="clave" type="password"
                                                    class="form-control <?php $__errorArgs = ['clave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="clave"
                                                    value="<?php echo e(old('clave')); ?>" placeholder="1">
                
                
                                            </div>

                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Close</button>
                                        <button type="button" wire:click="borrarProductoModal" class="btn btn-primary">Save</button>
                                    </div>
                                </div>
                            </div>
                        </div>




                    </div>

                    
                </div>
            </div>
        </div>
    </div>



</div><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/livewire/cargar-venta.blade.php ENDPATH**/ ?>