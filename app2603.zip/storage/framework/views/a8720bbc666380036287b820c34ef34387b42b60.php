

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Empresas</div>

                <div class="card-body">

                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success card shadow">
                        <p><?php echo e($message); ?></p>
                    </div>
                    <?php endif; ?>
                    
                    <div class="row mb-3 justify-content-around">
                        <div class="col-md-7">

                            <a name="" id="" class="btn btn-primary" 
                            href="<?php echo e(route('empresas.create')); ?>" role="button">Crear</a>
                            <a name="" id="" class="btn btn-primary" 
                            href="<?php echo e(route('empresas.reporte')); ?>" role="button">Excel</a>

                        </div>
                        <div class="col-md-5">

                            <form class="form-inline" method="GET" 
                            action="<?php echo e(route('empresas.search')); ?>">
                                <?php echo csrf_field(); ?>
                                <input class="form-control mr-sm-2" type="text" placeholder="Search"  name="search">
                                <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
                              </form>

                        </div>
                    </div>

                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Rif</th>
                                <th scope="col">email</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <th scope="row"><?php echo e($empresa->id); ?></th>
                                <td><?php echo e($empresa->nombre); ?></td>
                                <td><?php echo e($empresa->rif); ?></td>
                                <td><?php echo e($empresa->email); ?></td>
                                

                                <td><form action="<?php echo e(route('empresas.destroy', $empresa->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a name="" id="" class="btn btn-success"
                                    href="<?php echo e(route('empresas.edit', $empresa->id)); ?>" role="button"><i class="fas fa-pencil-alt"></i></a>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['isAdmin','isSuperadmin'])): ?>

                                        <button type="submit" class="btn btn-danger"><i class="far fa-trash-alt"></i></button>

                                    <?php endif; ?>
                                    
                                </form></td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                    <?php echo e($empresas->links()); ?>


                   

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bootstrap5\resources\views/empresas/index.blade.php ENDPATH**/ ?>