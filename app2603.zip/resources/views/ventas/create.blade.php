@extends('layouts.app')

@section('content')

        <livewire:cargar-venta/>         

@endsection