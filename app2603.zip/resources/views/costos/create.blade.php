@extends('layouts.app')

@section('content')

        <livewire:cargar-costo/>

@endsection