@extends('layouts.app')

@section('content')
<div class="container-fluid">

    <div class="row">
        <img src="{{ asset('storage/img/panaderia2min.png') }}" alt="" width="100%" height="100%">
    </div>  
    
</div>
@endsection
